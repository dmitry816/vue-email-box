<template>
	<div id="app">
		<email-list></email-list>
		<sidebar></sidebar>
	</div>
</template>

<script>

	import EmailList from './components/EmailList.vue';
	import Sidebar from './components/Sidebar.vue';

	export default {
		name: 'app',
		components: {
			emailList: EmailList,
			sidebar: Sidebar,
		},
		data() {
			return {
				messages: [
					{
						subject: 'How did we do?',
						content: `
							<p>Hello,</p>
							<p>You recently completed a purchase, and we'd like to know how we did. Your feedback is very important to us!</p>
							<p>Please click the following link to complete the survey. We're not going to lie, it will take way more than 5 minutes.</p>
							<p><a href="#">SurveyDonkey.com</a></p>
						`,
						from: {
							name: 'SurveyDonkey.com',
							email: 'survey@surveydonkey.com'
						},
					},
					{
						subject: 'How did we do?',
						content: `
							<p>Hello,</p>
							<p>You recently completed a purchase, and we'd like to know how we did. Your feedback is very important to us!</p>
							<p>Please click the following link to complete the survey. We're not going to lie, it will take way more than 5 minutes.</p>
							<p><a href="#">SurveyDonkey.com</a></p>
						`,
						from: {
							name: 'SurveyDonkey.com',
							email: 'survey@surveydonkey.com'
						},
					},
				]
			}
		}
	}
</script>

<style>
	#app {
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		text-align: center;
		color: #2c3e50;
		margin-top: 60px;
	}
</style>
