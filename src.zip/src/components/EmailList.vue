<template>
	<div>
		<div class="email-list-header">
			<span>Subject </span>
			<span>From </span>
			<span>Date </span>
		</div>
		<ul v-if="messages.length === 0">
           <li v-for="(message, subject, date) in messages" :key="message.index">
               {{message.messages}},{{subject}},{{date}}
            </li> 
        </ul>
        <p v-else>no messages</p>
	</div>
</template>

<script>
	export default {
        props: ['messages'],

		data: {
			
		}
	}

</script>
