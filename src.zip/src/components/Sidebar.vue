<template>
	<div class="sidebar">
		<create-email></create-email>
		<sent></sent>
	</div>
</template>

<script>

	import CreateEmail from './components/CreateEmail.vue';
	import Sent from './components/Sent.vue';

	export default {
		name: 'Sidebar',
		data: {
			msg: String,
		},
		components: {
			'create-email': CreateEmail,
			'sent': Sent,
		}	
	}
</script>
