<template>
    <div>
        <ul v-if="messages.length > 0">
           <li v-for="(message, subject, date) in messages" :key="message.index">
               {{message.messages}},{{subject}},{{date}}
            </li> 
        </ul>
        <p v-else>no sent messages</p>
    </div>
</template>

<script>
export default {
    name: 'Sent',
    data: {
        messages: messages,
    },
    components: {
        
    }
}
</script>
