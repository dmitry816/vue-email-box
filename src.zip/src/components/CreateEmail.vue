<template>
	<div id="create-email">
		<form>
			<div class="create-email-header">
				<div>
					<span>From</span>
				</div>
				<div>
					<label>Email </label>
					<input type="email">
				</div>
				<div>
					<label>Subject </label>
					<input type="text">
				</div>
			</div>
			<textarea rows="30" cols="90"></textarea>
		</form>
	</div>
</template>

<script>

	export default {
		name: 'CreateEmail',
		
		props: {
			
		}
	}
</script>
